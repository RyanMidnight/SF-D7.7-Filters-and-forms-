import string

SWEAR_WORDS = [
    'fuck',
    'fucking',
    'shit',
    'bitch',
    'dick',
    'tits',
    'boobs',
    'faggot',
    'nigger',
    'radish',
    'damn',
    'freak',
    'slave',
    'ass',
]


def punc(word):
    for symbol in string.punctuation:
        if symbol in word:
            return True
    else:
        return False


def substring(user_word):
    for swear_word in SWEAR_WORDS:
        if swear_word in user_word.lower():
            return True
    else:
        return False


def censor(value):
    values_list = value.split(' ')
    new_word_list = []
    for word in values_list:
        if substring(word):
            if punc(word):
                new_word = word[0] + ((len(word) - 2) * '*') + word[-1]
                new_word_list.append(new_word)
            else:
                new_word = word[0] + ((len(word) - 1) * '*')
                new_word_list.append(new_word)
        else:
            new_word_list.append(word)
    new_value = ' '.join(new_word_list)
    return new_value


print(censor('Fucking! niggers stole my damn, TV'))
